const axios = require('axios');
const cheerio = require('cheerio');

module.exports = function (app) {
    /**
     * TikTok User Posts Check Endpoint - Using Savett.cc
     * GET /marga/cekpost?username=USERNAME
     */
    app.get('/marga/cekpost', async (req, res) => {
        const { username } = req.query;
        
        if (!username) {
            return res.status(400).json({ 
                success: false,
                code: 400,
                message: 'Username parameter is required',
                timestamp: new Date().toISOString(),
                data: null
            });
        }

        try {
            const startTime = Date.now();
            
            // Step 1: Dapatkan salah satu video terbaru dari user
            const userPageUrl = `https://www.tiktok.com/@${username}`;
            const userPageRes = await axios.get(userPageUrl, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.9'
                },
                timeout: 15000
            });
            
            // Extract video ID dari page
            const videoMatches = [...userPageRes.data.matchAll(/video\/(\d+)/g)];
            if (videoMatches.length === 0) {
                throw new Error('No videos found for this user or account is private');
            }
            
            // Ambil video pertama (terbaru)
            const videoId = videoMatches[0][1];
            const videoUrl = `https://www.tiktok.com/@${username}/video/${videoId}`;
            
            // Step 2: Dapatkan token CSRF dari savett.cc
            const tokenRes = await axios.get('https://savett.cc/en1/download', {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
                }
            });
            
            const csrfToken = tokenRes.data.match(/name="csrf_token" value="([^"]+)"/)?.[1];
            const cookie = tokenRes.headers['set-cookie']?.map(v => v.split(';')[0]).join('; ') || '';
            
            if (!csrfToken) {
                throw new Error('Failed to get CSRF token');
            }
            
            // Step 3: Ambil info video dari savett.cc
            const videoRes = await axios.post(
                'https://savett.cc/en1/download',
                `csrf_token=${encodeURIComponent(csrfToken)}&url=${encodeURIComponent(videoUrl)}`,
                {
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Origin': 'https://savett.cc',
                        'Referer': 'https://savett.cc/en1/download',
                        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                        'Cookie': cookie
                    },
                    timeout: 30000
                }
            );
            
            // Step 4: Parse response dengan cheerio
            const $ = cheerio.load(videoRes.data);
            const processedTime = (Date.now() - startTime) / 1000;
            
            // Extract username dari page
            const pageUsername = $('#video-info h3').first().text().trim() || username;
            
            // Extract stats
            const statsText = [];
            $('#video-info .my-1 span').each((_, el) => {
                statsText.push($(el).text().trim());
            });
            
            // Extract download URLs (untuk keperluan info saja)
            const downloads = {
                no_watermark: null,
                watermark: null,
                audio: null
            };
            
            $('#formatselect option').each((_, el) => {
                const label = $(el).text().toLowerCase();
                const raw = $(el).attr('value');
                if (!raw) return;
                
                try {
                    const json = JSON.parse(raw.replace(/&quot;/g, '"'));
                    if (json.URL && json.URL.length > 0) {
                        if (label.includes('mp4') && !label.includes('watermark')) {
                            downloads.no_watermark = json.URL[0];
                        } else if (label.includes('watermark')) {
                            downloads.watermark = json.URL[0];
                        } else if (label.includes('mp3')) {
                            downloads.audio = json.URL[0];
                        }
                    }
                } catch (e) {
                    // Skip invalid JSON
                }
            });
            
            // Extract slides (untuk konten foto)
            const slides = [];
            $('.carousel-item[data-data]').each((idx, el) => {
                try {
                    const json = JSON.parse($(el).attr('data-data').replace(/&quot;/g, '"'));
                    if (Array.isArray(json.URL)) {
                        json.URL.forEach(url => {
                            slides.push({
                                index: slides.length + 1,
                                url: url
                            });
                        });
                    }
                } catch (e) {}
            });
            
            // Determine content type
            const contentType = slides.length > 0 ? 'slideshow' : 'video';
            
            // Format response lengkap
            const result = {
                success: true,
                code: 0,
                message: "success",
                processed_time: processedTime,
                timestamp: new Date().toISOString(),
                data: {
                    user: {
                        username: pageUsername,
                        requested_username: username,
                        video_url: videoUrl,
                        video_id: videoId
                    },
                    stats: {
                        views: statsText[0] || null,
                        likes: statsText[1] || null,
                        bookmarks: statsText[2] || null,
                        comments: statsText[3] || null,
                        shares: statsText[4] || null,
                        duration: $('#video-info p.text-muted').first().text().replace(/Duration:/i, '').trim() || null
                    },
                    content: {
                        type: contentType,
                        total_media: contentType === 'slideshow' ? slides.length : 1,
                        preview_url: contentType === 'slideshow' && slides.length > 0 ? slides[0].url : null
                    },
                    download_info: {
                        // Hanya info, bukan link download langsung (karena ini cekpost)
                        has_no_watermark: downloads.no_watermark !== null,
                        has_watermark: downloads.watermark !== null,
                        has_audio: downloads.audio !== null,
                        note: "Use /marga/ttdl endpoint to download this video"
                    }
                }
            };
            
            // Tambahkan slides jika ada
            if (contentType === 'slideshow') {
                result.data.content.slides = slides;
            }
            
            return res.json(result);
            
        } catch (error) {
            console.error('[TikTok CheckPost Error]:', error.message);
            
            // Handle specific errors
            let errorMessage = 'Failed to fetch user data';
            let errorCode = 500;
            
            if (error.message.includes('No videos found')) {
                errorMessage = 'User not found or has no public videos';
                errorCode = 404;
            } else if (error.message.includes('private') || error.response?.status === 404) {
                errorMessage = 'Account is private or does not exist';
                errorCode = 403;
            } else if (error.code === 'ECONNABORTED') {
                errorMessage = 'Request timeout';
                errorCode = 408;
            } else if (error.message.includes('CSRF')) {
                errorMessage = 'Service temporarily unavailable';
                errorCode = 503;
            }
            
            return res.status(errorCode).json({
                success: false,
                code: errorCode,
                message: errorMessage,
                timestamp: new Date().toISOString(),
                error_details: error.message,
                data: null
            });
        }
    });
};